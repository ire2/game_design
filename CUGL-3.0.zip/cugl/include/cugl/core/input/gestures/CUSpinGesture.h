//
//  CUSpinGesture.h
//  Cornell University Game Library (CUGL)
//
//  This class provides basic support for rotation gestures. Unlike the
//  CoreGesture device, this will always detect a spin, even when other
//  gestures are active.
//
//  This class is a singleton and should never be allocated directly.  It
//  should only be accessed via the Input dispatcher.
//
//  CUGL MIT License:
//      This software is provided 'as-is', without any express or implied
//      warranty.  In no event will the authors be held liable for any damages
//      arising from the use of this software.
//
//      Permission is granted to anyone to use this software for any purpose,
//      including commercial applications, and to alter it and redistribute it
//      freely, subject to the following restrictions:
//
//      1. The origin of this software must not be misrepresented; you must not
//      claim that you wrote the original software. If you use this software
//      in a product, an acknowledgment in the product documentation would be
//      appreciated but is not required.
//
//      2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//
//      3. This notice may not be removed or altered from any source distribution.
//
//  Author: Walker White
//  Version: 7/3/24 (CUGL 3.0 reorganization)
//
#ifndef __CU_SPIN_INPUT_H__
#define __CU_SPIN_INPUT_H__
#include <cugl/core/input/CUInput.h>
#include <cugl/core/math/CUVec2.h>

namespace cugl {

#pragma mark -
#pragma mark SpinEvent

/**
 * This simple class is a struct to hold a spin event.
 *
 * A spin event is a gesture with duration. Hence this event stores
 * information about the start of the event, as well as the current
 * status of the event.
 */
class SpinEvent {
public:
    /** The starting time of the gesture */
    Timestamp start;
    /** The current time of the gesture */
    Timestamp now;
	/** The normalized center of this pinch */
    Vec2 anchor;
    /** The initial angle of the spin */
    float origAngle;
    /** The current angle of the spin */
    float currAngle;
    /** The rotation delta since the last animation frame */
    float delta;
    
    /**
     * Constructs a new spin event with the default values
     */
    SpinEvent() :
        origAngle(0.0f),
        currAngle(0.0f),
        delta(0.0f) {}
    
    /**
     * Constructs a new spin event with the given values
     *
     * @param stamp     The timestamp for the event
     * @param anchor    The normalized pinch center
     * @param angle     The initial finger angle
     */
    SpinEvent(const Timestamp& stamp, const Vec2 anchor, float angle) {
        this->start = stamp;
        this->now = stamp;
        this->anchor = anchor;
        origAngle = angle;
        currAngle = angle;
        delta = 0.0f;
    }
    
    /**
     * Constructs a new pinch event that is a copy of the given one
     *
     * @param event     The event to copy
     */
    SpinEvent(const SpinEvent& event) {
        start = event.start;
        now  = event.now;
        anchor = event.anchor;
        origAngle = event.origAngle;
        currAngle = event.currAngle;
        delta = event.delta;
    }
    
    /**
     * Clears the contents of this spin event
     */
    void clear() {
        anchor.setZero();
        origAngle = 0.0f;
        currAngle = 0.0f;
        delta = 0.0f;
    }
};

    
#pragma mark -
#pragma mark SpinGesture
/**
 * This class is an input device recognizing spin events.
 *
 * A spin (or rotation) is a gesture where two or more fingers are rotated
 * about a single point on the device. Rotations and pinches often start with
 * the same initial gesture; the only difference is how the gesture changes
 * over time. For clarity, we have separated these two gestures.
 *
 * While some platforms allow spins with more than two fingers, currently
 * CUGL is limited to two-finger spins. Multi-finger spins are a
 * candidate for a future CUGL release.
 *
 * This input device is a touch device that supports multitouch gestures.
 * This is often the screen itself, but this is not always guaranteed.  For
 * example, the trackpad on MacBooks support pinches.  For that reason, we
 * cannot guarantee that the touches scale with the display.  Instead, all
 * gesture information is normalized, with the top left corner of the touch
 * device being (0,0) and the lower right being (1,1).
 *
 * If you know that the touch device is the screen, and would like to measure
 * the rotational anchor in screen coordinates, you should set the screen 
 * attribute to true with {@link setTouchScreen}.  In this case, the rotation
 * position will be scaled to its poisition on the screen. In those cases where 
 * the device is known to be the screen (Android, iOS devices), this value 
 * starts out as true.
 *
 * As with most devices, we provide support for both listeners and polling
 * the mouse.  Polling the device will query the touch screen at the start of
 * the frame, but it may miss those case in there are multiple angle changes in
 * a single animation frame.
 *
 * Listeners are guaranteed to catch all changes in the rotation angle, as long 
 * as they are detected by the OS.  However, listeners are not called as soon as
 * the event happens.  Instead, the events are queued and processed at the start
 * of the animation frame, before the method {@link Application#update(float)}
 * is called.
 */
class SpinGesture : public InputDevice {
public:
#pragma mark Listener
    /**
     * @typedef Listener
     *
     * This type represents a listener for a rotation in the {@link SpinGesture} class.
     *
     * In CUGL, listeners are implemented as a set of callback functions, not as
     * objects. This allows each listener to implement as much or as little
     * functionality as it wants. A listener is identified by a key which should
     * be a globally unique unsigned int.
     *
     * While rotation listeners do not traditionally require focus like a keyboard
     * does, we have included that functionality. While only one listener can have
     * focus at a time, all listeners will receive input from the RotationInput device.
     *
     * The function type is equivalent to
     *
     *      std::function<void(const RotationInput& event, bool focus)>
     *
     * @param event     The touch event for this pinch/zoom
     * @param focus     Whether the listener currently has focus
     */
    typedef std::function<void(const SpinEvent& event, bool focus)> Listener;
    
protected:
    /** Whether or not this input device is a touch screen */
    bool  _screen;
    /** Whether or not there is an active rotation being processed */
    bool  _active;
    /** The minimum radius for generating a spin event */
    float _radius;
    /** The movement stability for canceling a spin event */
    float _stability;
    /** The pinch event data (stored whether or not there is an event) */
    SpinEvent _event;
    
    /** The current finger positions */
    std::unordered_map<Sint64, Vec2> _fingers;
    /** The number of fingers updated this pass */
    size_t _updated;
    
    /** The set of listeners called whenever a pinch begins */
    std::unordered_map<Uint32, Listener> _beginListeners;
    /** The set of listeners called whenever a pinch ends */
    std::unordered_map<Uint32, Listener> _finishListeners;
    /** The set of listeners called whenever a pinch is moved */
    std::unordered_map<Uint32, Listener> _changeListeners;
    
    
#pragma mark Constructor
    /**
     * Creates and initializes a new rotation input device.
     *
     * WARNING: Never allocate a rotation input device directly.  Always use the
     * {@link Input#activate()} method instead.
     */
    SpinGesture();
    
    /**
     * Deletes this input device, disposing of all resources
     */
    virtual ~SpinGesture() {}
    
    /**
     * Initializes this device, acquiring any necessary resources
     *
     * @return true if initialization was successful
     */
    bool init() { return initWithName("Spin Gesture"); }

    /**
     * Unintializes this device, returning it to its default state
     *
     * An uninitialized device may not work without reinitialization.
     */
    virtual void dispose() override;
    
#pragma mark Device Attributes
public:
    /**
     * Returns true if this device is a touch screen.
     *
     * This device is not guaranteed to be a touch screen. For example, the
     * trackpad on MacBooks support rotations. We do try to make our best guess
     * about whether or not a device is a touch screen, but on some devices
     * this may need to be set manually.
     *
     * If this value is true, all rotation information will scale with the 
     * display. Otherwise, the rotation angle will be normalized to a unit 
     * square, where the top left corner of the touch device is (0,0) and the 
     * lower right is (1,1). You may want to set this value to false for true 
     * cross-platform gesture support.
     *
     * @return true if this device is a touch screen.
     */
    bool isTouchScreen() const { return _screen; }
    
    /**
     * Sets whether this device is a touch screen.
     *
     * This device is not guaranteed to be a touch screen. For example, the
     * trackpad on MacBooks support rotations. We do try to make our best guess
     * about whether or not a device is a touch screen, but on some devices
     * this may need to be set manually.
     *
     * If this value is true, all rotation information will scale with the
     * display. Otherwise, the rotation angle will be normalized to a unit
     * square, where the top left corner of the touch device is (0,0) and the
     * lower right is (1,1). You may want to set this value to false for true
     * cross-platform gesture support.
     *
     * @param flag  Whether this device is a touch screen.
     */
    void setTouchScreen(bool flag);
    
    /**
     * Returns the minimum radius for a spin event.
     *
     * All spins have an additional rquirement that all the fingers must be
     * separated by a minimum distance. This is a natural requirement for
     * spins, and it greatly reduces the possibility of accidental spins.
     *
     * If this device is a touch screen, this value should be measured in pixels.
     * Otherwise, this value should be set assuming a unit square, where the
     * top left corner of the touch device is (0,0) and the lower right is (1,1).
     * By default this value is 10% of the length of the diagonal of the touch
     * device.
     *
     * @return the minimum radius for a spin event.
     */
    float getMinimumRadius() const { return _radius; }

    /**
     * Sets the minimum radius for a spin event.
     *
     * All spins have an additional rquirement that all the fingers must be
     * separated by a minimum distance. This is a natural requirement for
     * spins, and it greatly reduces the possibility of accidental spins.
     *
     * If this device is a touch screen, this value should be measured in pixels.
     * Otherwise, this value should be set assuming a unit square, where the
     * top left corner of the touch device is (0,0) and the lower right is (1,1).
     * By default this value is 10% of the length of the diagonal of the touch
     * device.
     *
     * @param radius    The minimum radius for a spin event.
     */
    void setMinimumRadius(float radius);
    
    /**
     * Returns the movement stability of a spin event.
     *
     * A spin will be canceled if it encounters two much "lateral" movement.
     * Here lateral that the centroid of the spin changes significantly from
     * the initial centroid.
     *
     * If this device is a touch screen, this value should be measured in pixels.
     * Otherwise, this value should be set assuming a unit square, where the
     * top left corner of the touch device is (0,0) and the lower right is (1,1).
     * By default this value is 10% of the length of the diagonal of the touch
     * device.
     *
     * @return the movement stability of a spin event.
     */
    float getStability() const { return _stability; }
    
    /**
     * Sets the movement stability of a spin event.
     *
     * A spin will be canceled if it encounters two much "lateral" movement.
     * Here lateral that the centroid of the spin changes significantly from
     * the initial centroid.
     *
     * If this device is a touch screen, this value should be measured in pixels.
     * Otherwise, this value should be set assuming a unit square, where the
     * top left corner of the touch device is (0,0) and the lower right is (1,1).
     * By default this value is 10% of the length of the diagonal of the touch
     * device.
     *
     * @param stability The movement stability of a spin event.
     */
    void setStability(float stability);
    
    
#pragma mark Data Polling
    /**
     * Returns true if the device is in the middle of an active rotation.
     *
     * If the device is not an in active rotation, all other polling methods
     * will return the default value.
     *
     * @return true if the device is in the middle of an active rotation.
     */
    bool isActive() const { return _active; }
    
    /**
     * Returns the change in the rotation angle since the last animation frame.
     *
     * This value is positive if the rotation is counter-clockwise, and negative
     * if it is clockwise.  All values are in radians.
     *
     * @return the change in the rotation angle since the last animation frame.
     */
    float getDelta() const { return _active ? _event.delta : 0.0f; }
    
    /**
     * Returns the cumulative angular change since the gesture began.
     *
     * This value is positive if the rotation is counter-clockwise, and negative
     * if it is clockwise.  All values are in radians.
     *
     * @return the cumulative pinch distance since the gesture began.
     */
    float getRotation() const;
    
    /**
     * Returns the normalized center of the spin.
     *
     * This value is defined at the start of the spin gesture and remains
     * unchanged.
     *
     * @return the normalized center of the spin.
     */
    const Vec2 getPosition() const { return _active ? _event.anchor : Vec2::ZERO; }
    
    
#pragma mark Listeners
    /**
     * Requests focus for the given identifier
     *
     * Only a listener can have focus.  This method returns false if key
     * does not refer to an active listener
     *
     * @param key   The identifier for the focus object
     *
     * @return false if key does not refer to an active listener
     */
    virtual bool requestFocus(Uint32 key) override;
    
    /**
     * Returns true if key represents a listener object
     *
     * An object is a listener if it is a listener for any of the three actions:
     * rotation begin, rotation end, or rotation change.
     *
     * @param key   The identifier for the listener
     *
     * @return true if key represents a listener object
     */
    bool isListener(Uint32 key) const;
    
    /**
     * Returns the rotational begin listener for the given object key
     *
     * This listener is invoked when the rotation crosses the angular threshold.
     *
     * If there is no listener for the given key, it returns nullptr.
     *
     * @param key   The identifier for the listener
     *
     * @return the rotational begin listener for the given object key
     */
    const Listener getBeginListener(Uint32 key) const;
    
    /**
     * Returns the rotational end listener for the given object key
     *
     * This listener is invoked when all (but one) fingers in an active rotation
     * are released.
     *
     * If there is no listener for the given key, it returns nullptr.
     *
     * @param key   The identifier for the listener
     *
     * @return the rotational end listener for the given object key
     */
    const Listener getEndListener(Uint32 key) const;
    
    /**
     * Returns the rotational change listener for the given object key
     *
     * This listener is invoked when the rotation angle changes.
     *
     * @param key   The identifier for the listener
     *
     * @return the rotational change listener for the given object key
     */
    const Listener getChangeListener(Uint32 key) const;
    
    /**
     * Adds a rotational begin listener for the given object key
     *
     * There can only be one listener for a given key.  If there is already
     * a listener for the key, the method will fail and return false.  You
     * must remove a listener before adding a new one for the same key.
     *
     * This listener is invoked when the rotation crosses the angular threshold.
     *
     * @param key       The identifier for the listener
     * @param listener  The listener to add
     *
     * @return true if the listener was succesfully added
     */
    bool addBeginListener(Uint32 key, Listener listener);
    
    /**
     * Adds a rotational end listener for the given object key
     *
     * There can only be one listener for a given key.  If there is already
     * a listener for the key, the method will fail and return false.  You
     * must remove a listener before adding a new one for the same key.
     *
     * This listener is invoked when all (but one) fingers in an active pinch
     * are released.
     *
     * @param key       The identifier for the listener
     * @param listener  The listener to add
     *
     * @return true if the listener was succesfully added
     */
    bool addEndListener(Uint32 key, Listener listener);
    
    /**
     * Adds a rotational change listener for the given object key
     *
     * There can only be one listener for a given key.  If there is already
     * a listener for the key, the method will fail and return false.  You
     * must remove a listener before adding a new one for the same key.
     *
     * This listener is invoked when the rotation angle changes.
     *
     * @param key       The identifier for the listener
     * @param listener  The listener to add
     *
     * @return true if the listener was succesfully added
     */
    bool addChangeListener(Uint32 key, Listener listener);
    
    /**
     * Removes the rotational begin listener for the given object key
     *
     * If there is no active listener for the given key, this method fails and
     * returns false.
     *
     * This listener is invoked when the rotation crosses the angular threshold.
     *
     * @param key   The identifier for the listener
     *
     * @return true if the listener was succesfully removed
     */
    bool removeBeginListener(Uint32 key);
    
    /**
     * Removes the rotational end listener for the given object key
     *
     * If there is no active listener for the given key, this method fails and
     * returns false.
     *
     * This listener is invoked when all (but one) fingers in an active rotation
     * are released.
     *
     * @param key   The identifier for the listener
     *
     * @return true if the listener was succesfully removed
     */
    bool removeEndListener(Uint32 key);
    
    /**
     * Removes the rotational change listener for the given object key
     *
     * If there is no active listener for the given key, this method fails and
     * returns false.
     *
     * This listener is invoked when the rotation angle changes.
     *
     * @param key   The identifier for the listener
     *
     * @return true if the listener was succesfully removed
     */
    bool removeChangeListener(Uint32 key);
    
    
protected:
#pragma mark Input Device
    /**
     * Clears the state of this input device, readying it for the next frame.
     *
     * Many devices keep track of what happened "this" frame.  This method is
     * necessary to advance the frame.
     */
    virtual void clearState() override;
    
    /**
     * Processes an SDL_Event
     *
     * The dispatcher guarantees that an input device only receives events that
     * it subscribes to.
     *
     * @param event The input event to process
     * @param stamp The event timestamp in CUGL time
     *
     * @return false if the input indicates that the application should quit.
     */
    virtual bool updateState(const SDL_Event& event, const Timestamp& stamp) override;
    
    /**
     * Returns the scale/unscaled touch position.
     *
     * The value returned depends on the value of attribute _screen.  If this
     * attribute is false, the position is normalized to the unit square.
     * Otherwise it is scaled to the touch screen.
     *
     * @return the scale/unscaled touch position.
     */
    Vec2 getScaledPosition(float x, float y) const;
    
    /**
     * Determine the SDL events of relevance and store there types in eventset.
     *
     * An SDL_EventType is really Uint32.  This method stores the SDL event
     * types for this input device into the vector eventset, appending them
     * to the end. The Input dispatcher then uses this information to set up
     * subscriptions.
     *
     * @param eventset  The set to store the event types.
     */
    virtual void queryEvents(std::vector<Uint32>& eventset) override;
    
#pragma mark Internal Helpers
private:
    /**
     * Returns the centroid of the fingers
     *
     * The centroid is the average of all the fingers on the touch device.
     *
     * @return the centroid of the fingers
     */
    Vec2 computeCentroid() const;

    /**
     * Returns the axis of the fingers
     *
     * Naively, the axis is defined as the vector from the first finger
     * to the second. However, to enforce some stability, this method
     * assumes the axis always travels through the initial centroid of
     * the gesture. As the centroid may drift, this is not always the
     * case. To compensate, this method computes the weighted average
     * from the first finger to the centroid, and from the centroid to
     * the second finger.
     *
     * @return the axis of the fingers
     */
    Vec2 computeAxis() const;

    /**
     * Reinitializes the pinch event for a new gesture.
     *
     * This method calls all of the begin listeners with the new
     * gesture information.
     *
     * @param stamp The initial timestamp of the new gesture
     */
    void startGesture(const Timestamp& stamp);

    /**
     * Finalizes the pinch event, preparing for a new gesture.
     *
     * This method calls all of the end listeners with the final
     * gesture information.
     *
     * @param stamp The final timestamp of the gesture
     */
    void cancelGesture(const Timestamp& stamp);
    
    // Apparently friends are not inherited
    friend class Input;
};

}
#endif /* __CU_ROTATION_INPUT_H__ */
