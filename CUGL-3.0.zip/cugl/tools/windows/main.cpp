// This program does nothing.  It only exists to capture linkage information
#include <iostream>
#include <string>

int main() {
    std::cout << "Hello World" << std::endl;
    return 0;
}
