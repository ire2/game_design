# CUGL Licenses

CUGL is not possible without the hard work of many others that provide the cross-platform libraries. This directory contains the licenses of all of the software that makes CUGL possible.

These licenses are packaged with every application made with the CUGL engine.